package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GameService {

    private static GameService instance;
public static List<Game> games = new ArrayList<Game>();
private static long nextGameId = 1;

    private GameService() {
    }

    public static GameService getInstance() {
        if (instance == null) {
            instance = new GameService();
        }
        return instance;
    }

    public Game addGame(String name) {
        Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            Game existingGame = iterator.next();
            if (existingGame.getName().equals(name)) {
                return existingGame;
            }
        }

        Game game = new Game(nextGameId++, name);
        games.add(game);
        return game;
    }

    Game getGame(int index) {
        return games.get(index);
    }

    public Game getGame(long id) {
        Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            Game existingGame = iterator.next();
            if (existingGame.getId() == id) {
                return existingGame;
            }
        }
        return null;
    }

    public Game getGame(String name) {
        Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            Game existingGame = iterator.next();
            if (existingGame.getName().equals(name)) {
                return existingGame;
            }
        }
        return null;
    }

    public int getGameCount() {
        return games.size();
    }
}
