package com.gamingroom.gameauth;

import io.dropwizard.Configuration;

public class GameAuthConfiguration extends Configuration {

}